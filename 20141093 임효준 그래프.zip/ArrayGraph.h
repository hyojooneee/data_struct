#pragma once
#include "Graph.h"


class ArrayGraph :public Graph
{
private :
	int **matrix;
public :
	ArrayGraph() 
	{
		matrix = new int*[n];
		for (int i = 0; i < n; i++)
		{
			matrix[i] = new int[n];
		}
	}
	~ArrayGraph()
	{
		for (int i = 0; i < n; i++)
			delete[] matrix[i];

		delete[] matrix;
	}
	void setMatrix(int _n);
	void InsertEdge(int x, int y);
	void printMatrix();
	void DFS();
	void DFS(int _vertex);
	void BFS();
	void BFS(int _vertex);
};