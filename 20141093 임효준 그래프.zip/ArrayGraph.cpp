#include "ArrayGraph.h"

void ArrayGraph::setMatrix(int _n)
{
	for (int i = 0; i < n; i++)
		delete[] matrix[i];

	delete[] matrix;

	this->n = _n;

	int **newMatrix = new int*[n];

	for (int i = 0; i < n; i++)
		newMatrix[i] = new int[n];

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			newMatrix[i][j] = 0;
	}
	
	matrix = newMatrix;
}

void ArrayGraph::InsertEdge(int x, int y)
{
	matrix[x][y] = 1;
	matrix[y][x] = 1;
}

void ArrayGraph::printMatrix()
{
	cout << "�Էµ� �׷����� ���� ��� ǥ��" << endl;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << matrix[i][j] << " ";
		}
		cout << endl;
	}

}

void ArrayGraph::DFS()
{
	visited = new bool[n];
	fill(visited, visited + n, false);
	int count = 0;

	cout << "������" << endl;
	cout << "1.	������� + DFS" << endl;

	for (int w = 0; w < n; w++)
	{
		if (!visited[w])
		{
			count++;
			cout << "	������" << count << " - ";
			DFS(w);
			cout << endl;
		}
	}
}

void ArrayGraph::DFS(int _vertex)
{
	cout << _vertex << " ";
	visited[_vertex] = true;
	for (int w = 0; w < n; w++)
	{
		if (!visited[w] && matrix[_vertex][w] == 1)
			DFS(w);
	}
}

void ArrayGraph::BFS()
{
	visited = new bool[n];
	fill(visited, visited + n, false);
	int count = 0;

	cout << "2.	������� + BFS" << endl;

	for (int i = 0; i < n; i++)
	{
		if (!visited[i])
		{
			count++;
			cout << "	������" << count << " - ";
			BFS(i);
			cout << endl;
		}
	}
}

void ArrayGraph::BFS(int _vertex)
{
	cout << _vertex << " ";
	visited[_vertex] = true;

	queue<int> q;

	q.push(_vertex);

	while (!q.empty())
	{
		for (int w = 0; w < n; w++)
		{
			if (!visited[w] && matrix[_vertex][w] == 1)
			{
				q.push(w);
				cout << w << " ";
				visited[w] = true;
			}
		}
		_vertex = q.front();
		q.pop();
	}

}