#include "Filehandler.h"

void Filehandler::read_S(string file_name, ArrayGraph& ag,ListGraph& lg)
{
	ifstream fin;
	fin.open(file_name);
	if (fin.fail())
		throw "���� ���� ����";

	int _n, v1, v2;

	fin >> _n;
	ag.setMatrix(_n);
	lg.setList(_n);
	while (!fin.eof())
	{
		fin >> v1 >> v2;
		if (v1 == -1)
			break;
		ag.InsertEdge(v1, v2);
		lg.InsertEdge(v1, v2);
	}
	fin.close();
}

void Filehandler::read_T(string file_name, ListGraph& lg)
{
	ifstream fin;
	fin.open(file_name);
	if (fin.fail())
		throw "���� ���� ����";

	int _n, v1, v2;

	fin >> _n;
	lg.setList(_n);
	while (!fin.eof())
	{
		fin >> v1 >> v2;
		if (v1 == -1)
			break;
		lg.InsertEdgeT(v1, v2);
	}


	fin.close();
}