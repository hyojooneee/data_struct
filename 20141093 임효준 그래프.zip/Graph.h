#pragma once
#include <iostream>
#include <string>
#include <queue>
#include <stack>
using namespace std;

class Graph {
protected:
	int n;	//������ ��
	int e; //������ ��
	bool* visited;	//�湮Ȯ��
public:
	Graph() { n = 10; e = 0; }
	Graph(int n, int e) { this->n = n; this->e = e; }
	~Graph() { delete[] visited; }
	bool IsEmpty() const { return n == 0; }
	int NumberOfVertives() const { return n; }
	int NumberOf_vertexs() const { return e; }


	//virtual int Degree(int u) const = 0;
	//virtual bool Exists_vertex(int u, int v) const = 0;
	//virtual void InsertVertex(int v) = 0;
	//virtual void InsertEdge(int e, int v) = 0;
	//virtual void Insert_vertex(int u, int v) = 0;
	//virtual void DeleteVertex(int v) = 0;
	//virtual void Delete_vertex(int u, int v) = 0;
};

