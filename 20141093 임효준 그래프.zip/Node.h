#pragma once

class Node
{
	friend class Graph;
private:
	int vertex;
	Node* link;

public:
	Node() {
		vertex = 0;
		link = 0; }
	~Node() { }
	Node(int _vertex, Node* next)
	{
		this->vertex = _vertex;
		this->link = next;
	}

	//get
	int getVertex() { return vertex; }
	Node *getLink() { return link; }

	//set
	void setVertex(int _vertex)	{vertex = _vertex;}
	void setLink(Node* _link) { link = _link; }
};