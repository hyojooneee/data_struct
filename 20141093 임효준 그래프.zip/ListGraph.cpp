#include"ListGraph.h"

void ListGraph::setList(int _n)
{
	delete[] list;
	this->n = _n;
	Node *newList = new Node[n];
	for (int i = 0; i < n; i++)
	{
		newList[i] = Node(i, NULL);
	}
	list = newList;
}

void ListGraph::InsertEdge(int x, int y)
{
	if (list[x].getLink() == 0)
	{
		Node* insertNode = new Node(y, 0);
		list[x].setLink(insertNode);
	}
	else
	{
		Node* insertNode = new Node(y, 0);
		insertNode->setLink(list[x].getLink());
		list[x].setLink(insertNode);
	}

	if (list[y].getLink() == 0)
	{
		Node* insertNode = new Node(x, 0);
		list[y].setLink(insertNode);
	}
	else
	{
		Node* insertNode = new Node(x, 0);
		insertNode->setLink(list[y].getLink());
		list[y].setLink(insertNode);
	}

}

void ListGraph::InsertEdgeT(int x, int y)
{
	if (list[x].getLink() == 0)
	{
		Node* insertNode = new Node(y, 0);
		list[x].setLink(insertNode);
	}
	else
	{
		Node* insertNode = new Node(y, 0);
		insertNode->setLink(list[x].getLink());
		list[x].setLink(insertNode);
	}
}

void ListGraph::printList()
{
	cout << "�Էµ� �׷����� ���� ����Ʈ ǥ��" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << list[i].getVertex() << " -> ";

		if (list[i].getLink() == NULL)
		{
			cout << "null" << endl;
			continue;
		}

		else
		{
			Node *curNode = list[i].getLink();	// ��� �ִ� ����Ʈ�� ������ ����� ����Ű�� ��� ���� ������.
			while (true)
			{
				cout << curNode->getVertex() << " ";

				if (curNode->getLink() == NULL)
					break;

				cout << " - ";

				curNode = curNode->getLink();
			}
			cout << endl;
		}
	}
}

void ListGraph::DFS()
{
	visited = new bool[n];
	fill(visited, visited + n, false);
	int count = 0;

	cout << "3.	��������Ʈ + DFS" << endl;

	for (int w = 0; w < n; w++)
	{
		if (!visited[w])
		{
			count++;
			cout << "	������" << count << " - ";
			DFS(w);
			cout << endl;
		}
	}

}

void ListGraph::DFS(int _vertex)
{
	visited[_vertex] = true;
	cout << _vertex << " ";

	Node *curNode = &list[_vertex];

	while (true)
	{
		if (curNode->getLink() == NULL)
			break;

		curNode = curNode->getLink();

		if (visited[curNode->getVertex()] == false)
			DFS(curNode->getVertex());
	}
}

void ListGraph::BFS()
{
	visited = new bool[n];
	fill(visited, visited + n, false);
	int count = 0;

	cout << "4.	��������Ʈ + BFS" << endl;

	for (int i = 0; i < n; i++)
	{
		if (!visited[i])
		{
			count++;
			cout << "	������" << count << " - ";
			BFS(i);
			cout << endl;
		}
	}
}

void ListGraph::BFS(int _vertex)
{
	cout << _vertex << " ";
	visited[_vertex] = true;

	queue<Node *> q;

	Node *curNode = &list[_vertex];

	q.push(curNode);

	while (!q.empty())
	{
		while (1)
		{
			if (curNode->getLink() == NULL)
				break;

			curNode = curNode->getLink();

			if (visited[curNode->getVertex()] == false)
			{
				q.push(&list[curNode->getVertex()]);
				cout << curNode->getVertex() << " ";
				visited[curNode->getVertex()] = true;
			}
		}
		curNode = q.front();
		q.pop();

	}
}

void ListGraph::TopologicalOrder()
{
	cout << "������ �ϳ��� ���� ����  : ";
	stack<int>s;
	int* CountArr;
	CountArr = new int[n];
	for (int i = 0; i < n; i++)
		CountArr[i] = 0;
	//�ʱ�ȭ

	for (int i = 0; i < n; i++)
	{
		Node *curNode = &list[i];
		while (true)
		{
			if (curNode->getLink() == NULL)
				break;

			curNode = curNode->getLink();

			CountArr[curNode->getVertex()]++;

		}
	}
	// �迭�� �� �ֱ�

	for (int i = 0; i < n; i++)
	{
		if (CountArr[i] == 0)
			s.push(i);
	}

	while (!s.empty())
	{
		cout << s.top() << " ";
		Node *curNode = &list[s.top()];

		s.pop();
		while (true)
		{
			if (curNode->getLink() == 0)
				break;

			curNode = curNode->getLink();

			CountArr[curNode->getVertex()]--;

			if (CountArr[curNode->getVertex()] == 0)
				s.push(curNode->getVertex());
		}
	}
	cout << endl;
}