#pragma once
#include <fstream>
#include "ArrayGraph.h"
#include "ListGraph.h"

class Filehandler {
public :
	void read_S(string file_name, ArrayGraph& ag, ListGraph& lg);
	void read_T(string file_name, ListGraph& lg);
};