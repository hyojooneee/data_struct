#pragma once
#include "Graph.h"
#include "Node.h"


class ListGraph : public Graph {
private:
	Node* list;
public:
	ListGraph()
	{
		list = new Node[n];
	}

	~ListGraph()
	{
		delete[] list;
	}
	void setList(int _n);
	void InsertEdge(int x, int y);
	void InsertEdgeT(int x, int y);
	void printList();

	void DFS();
	void DFS(int _vertex);

	void BFS();
	void BFS(int _vertex);

	void TopologicalOrder();
};