#include "Expression.h"

void Expression::input_expression()
{
	//cin.ignore();
	getline(cin, expression, '\n');
}

int Expression::isp(char o)
{
	switch (o)
	{
	case '(': return 8;
	case '~': return 1;
	case '!': return 1;
	case '^': return 2;
	case '*': return 3;
	case '/': return 3;
	case '%': return 3;
	case '+': return 4;
	case '-': return 4;
	case '#': return 8;
	}
}

int Expression::icp(char o)
{
	switch (o)
	{
	case '(': return 0;
	case '~': return 1;
	case '!': return 1;
	case '^': return 2;
	case '*': return 3;
	case '/': return 3;
	case '%': return 3;
	case '+': return 4;
	case '-': return 4;
	case '#': return 8;
	}
}

void Expression::postfix_notation() {
	stack <char> op;
	op.push('#');
	for (int i = 0; i < expression.length(); i++)
	{
		if (0 <= expression[i] - '0' && expression[i] - '0' < 10)
		{
			if (0 <= expression[i + 1] - '0' && expression[i + 1] - '0' < 10)
			{
				cout << expression[i];
				post_expression += expression[i];
			}
			else if (expression[i + 1] == ' ' && 0 <= expression[i + 2] - '0' && expression[i + 2] - '0' < 10)
			{
				cout << "[����] ������ �� ���� ����" << endl;
				break;
			}
			else {
				cout << expression[i] << " ";
				post_expression += expression[i];
				post_expression += ' ';
			}
		}
		switch (expression[i])
		{
		case ' ': {break; }
		case '(':
		case '~':
		case '!':
		case '^':
		case '*':
		case '/':
		case '%':
		case '+':
		case '-':
		case ')':
		{
			if (expression[i] == ')')
			{
				while (op.top() != '(')
				{
					cout << op.top() << " ";
					post_expression += op.top();
					post_expression += ' ';
					op.pop();
				}
			}
			else if (icp(expression[i]) < isp(op.top()))
			{
				op.push(expression[i]);
				break;
			}
			else if (icp(expression[i]) >= isp(op.top()))
			{
				while (icp(expression[i]) >= isp(op.top()))
				{
					cout << op.top() << " ";
					post_expression += op.top();
					post_expression += ' ';
					op.pop();
				}
				op.push(expression[i]);

			}
		}
		}
	}
	for (; op.top() != '#'; op.pop())
	{
		if (op.top() == ')' || op.top() == '(')
			continue;
		cout << op.top() << " ";
		post_expression += op.top();
		post_expression += ' ';
	}
	cout << endl;
}