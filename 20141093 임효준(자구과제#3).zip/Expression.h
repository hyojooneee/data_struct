#pragma once
#include <iostream>
#include <string>
#include <stack>
using namespace std;

class Expression {
private : 
	string expression;
	string post_expression;
public : 
	void input_expression();
	int isp(char o);
	int icp(char o);
	void postfix_notation();
	string get_post_expression() { return post_expression; }
	string get_expression() { return expression; }
};