#include "Calculator.h"

bool Calculator::isoperator(char o)
{
	switch (o)
	{
	case ' ':
	case '(':
	case '~':
	case '!':
	case '^':
	case '*':
	case '/':
	case '%':
	case '+':
	case '-':
	case ')':
		return true;
	default :
		return false;
	}
}

void Calculator::calculation(Expression e) 
{
	string exp = e.get_post_expression();
	string temp;
	int o1, o2;
	int index = 0;
	while (1)
	{
		index = exp.find(' ');
		temp = exp.substr(0, index + 1);
		for (int i = 0; i < exp.find(' '); i++)
		{
			if (isoperator(temp[i]) == true)
			{
				switch (temp[i])
				{
				case '~': o1 = result.top(); result.pop();
					o1 = -1 * o1;
					result.push(o1);
					break;
				case '!': o1 = result.top(); result.pop();
					if (o1 == 0) result.push(1);
					else result.push(0);
				case '^':
					o2 = result.top(); result.pop();
					o1 = result.top(); result.pop();
					o1 = pow(o1,o2);
					result.push(o1);
					break;
				case '*':
					o2 = result.top(); result.pop();
					o1 = result.top(); result.pop();
					o1 = o1 * o2;
					result.push(o1);
					break;
				case '/':
					o2 = result.top(); result.pop();
					o1 = result.top(); result.pop();
					if (o2 == 0) {
						cout << "[����] �������� �ι�° �����ڰ� 0�� ��찡 �߻�"<<endl;
						return;
					}
					o1 = o1 / o2;
					result.push(o1);
					break;
				case '%':					
					o2 = result.top(); result.pop();
					o1 = result.top(); result.pop();
					if (o2 == 0) {
						cout << "[����] �������� �ι�° �����ڰ� 0�� ��찡 �߻�" << endl;
						return;
					}
					o1 = o1 % o2;
					result.push(o1);
					break;
				case '+': 
					o2 = result.top(); result.pop();
					o1 = result.top(); result.pop();
					o1 = o1 + o2;
					result.push(o1);
					break;
				case '-':					
					o2 = result.top(); result.pop();
					o1 = result.top(); result.pop();
					o1 = o1 - o2;
					result.push(o1);
					break;
				}
			}
			else
			{
				result.push(stoi(temp));
			}
		}
		exp.erase(0, temp.length());
		if (exp.empty() == true)
		{
			cout << result.top() << endl;
			break;
		}
	}
}
