#pragma once
#include "expression.h"
using namespace std;

class Calculator {
private : 
	stack <int> result;
	stack <char> Cal_operator;
public :
	bool isoperator(char o);
	void calculation(Expression e);

};