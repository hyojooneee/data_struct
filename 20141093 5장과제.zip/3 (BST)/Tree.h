#pragma once
#include "TreeNode.h"
#include "Queue.h"

template <class T>
class Tree
{
private:
	TreeNode<T>* root;
	int count;
public:
	Tree(string name) { root = new TreeNode<T>(name); count = 0; }
	~Tree() {};

	void insertName(TreeNode<T>* current, string name);
	void setTree(string name) { insertName(root, name); }
	void printTree(int count,TreeNode<T>* current);
	void show() { printTree(root); }

	TreeNode<T>* getRoot() { return root; }
};

template <class T>
void Tree<T>::insertName(TreeNode<T>* current, string name)
{
	if (current->name.compare(name) < 0)       // current->name �� name ���� ���������� ���� ��
	{
		if (!current->rightChild || current->rightChild->name == "0")
		{
			TreeNode<T>* newNode = new TreeNode<T>(name);
			current->rightChild = newNode;
			if (!current->leftChild) current->leftChild = new TreeNode<T>("0");
		}
		else insertName(current->rightChild, name);
	}
	else if (current->name.compare(name) > 0)  // current->name �� name ���� ���������� ���� ��
	{
		if (!current->leftChild || current->leftChild->name == "0")
		{
			TreeNode<T>* newNode = new TreeNode<T>(name);
			current->leftChild = newNode;

			if (!current->rightChild) current->rightChild = new TreeNode<T>("0");
		}
		else insertName(current->leftChild, name);
	}

}

template <class T>
void Tree<T>::printTree(int count,TreeNode<T>* current)
{
	
	if (current != root)
	{
		cout << " --- ";
		count++;
	}

	cout << current->name;

	if (current->leftChild == 0 && current->rightChild != 0)
		cout << " --- 0";

	else if (current->leftChild != 0)
		printTree(count,current->leftChild);

	if (current->rightChild != 0)
	{
		cout << endl << "      ";
		for (int k = 0; k < count; k++)
			cout << "           ";

		printTree(count,current->rightChild);
	}
}