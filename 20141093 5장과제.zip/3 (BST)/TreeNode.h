#pragma once
#include <iostream>
#include <string>
using namespace std;

template <class T> class Tree;

template <class T>
class TreeNode
{
private:
	TreeNode<T>* leftChild;
	T name;
	TreeNode<T>* rightChild;

public:
	friend class Tree<T>;
	TreeNode() {};
	TreeNode(T name) { this->name = name; leftChild = NULL; rightChild = NULL; }
	~TreeNode() {};
};

