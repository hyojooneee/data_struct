#pragma once
#include "TreeNode.h"

template<class T>
class Tree
{
protected:
	TreeNode<T> *root;
public:
	Tree() { root = new TreeNode<T>; }
	TreeNode<T>* getRoot() { return root; }
};