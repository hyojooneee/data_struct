#pragma once
#include "TokenList.h"
#include <iostream>
#include <string>
#include <stack>

class Calculator
{
private:
	string expression;
	TokenList backExpression;
	TokenList tList;
	stack<char> letterS;
public:
	Calculator() {}
	void execute();
	TokenList getBackExpression();
	void error(char a, char b);
	void priority(char item);
};

