#include "Calculator.h"
#include "CalculatorTree.h"

int main()
{
	while (1)
	{
		try
		{
			Calculator cal;
			cal.execute();

			TokenList backExpression = cal.getBackExpression();

			CalculatorTree<Token> tree;

			for (int i = 0; i < backExpression.getSize(); i++)
			{
				tree.FormTree(backExpression.getToken(i));
			}

			tree.Print(0, tree.getRoot());
			cout << endl;
			cout << "---- ����� " << tree.getRoot()->getData().getNum() << endl << endl;
		}
		catch (char* message)
		{
			cout << message << endl;
			if (message == "**** �����մϴ� ****")
				break;
			cout << endl;
		}
	}
	return 0;
}