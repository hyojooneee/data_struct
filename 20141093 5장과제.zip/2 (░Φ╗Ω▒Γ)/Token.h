#pragma once

typedef struct
{
	float num;
	char letter;
}token;

class Token
{
private:
	bool state;
	token tok;
public:
	Token() {}
	Token(float num_n) { tok.num = num_n; state = true; }
	Token(char letter_l) { tok.letter = letter_l; state = false; }
	~Token() {}

	float getNum() { return tok.num; }
	int getLetter() { return tok.letter; }
	bool getState() { return state; }

	void setNum(float num_n) { tok.num = num_n; }
	void setLetter(char letter_l) { tok.letter = letter_l; }
};