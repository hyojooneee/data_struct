#pragma once
#include<iostream>
using namespace std;

template<class T> class Tree;
template<class T> class CalculatorTree;

template<class T>
class TreeNode
{
	friend class Tree<T>;
	friend class CalculatorTree<T>;
private:
	T data;
	TreeNode<T> *leftChild;
	TreeNode<T> *rightChild;
public:
	TreeNode() : leftChild(0), rightChild(0) {}
	TreeNode(T data_d) :data(data_d), leftChild(0), rightChild(0) {}

	T getData() { return data; }
};

