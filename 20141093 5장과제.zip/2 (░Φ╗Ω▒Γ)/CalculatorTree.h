#pragma once
#include "Tree.h"
#include <stack>

template<class T>
class CalculatorTree : public Tree<T>
{
private:
	stack<TreeNode<T>*> stack;
public:
	CalculatorTree() { Tree<T>(); }

	void FormTree(T input);
	void Print(int i, TreeNode<T> *currentNode);
};

template<class T>
void CalculatorTree<T>::FormTree(T input)
{
	if (input.getState() == false)	
	{
		TreeNode<T>* letter = new TreeNode<T>(input);
		TreeNode<T>* num2 = stack.top();
		stack.pop();

		if (input.getLetter() == '~')
		{
			letter->leftChild = num2;
			letter->data.setNum(-(num2->data.getNum()));
		}

		else if (input.getLetter() == '!')
		{
			letter->leftChild = num2;
			if(num2->data.getNum() ==0)
				letter->data.setNum(1);
			else
				letter->data.setNum(0);
		}

		else
		{
			TreeNode<T>* num1 = stack.top();
			stack.pop();
			letter->leftChild = num1;
			letter->rightChild = num2;

			switch (input.getLetter())
			{
			case '-':
				letter->data.setNum(num1->data.getNum() - num2->data.getNum());
				break;
			case '+':
				letter->data.setNum(num1->data.getNum() + num2->data.getNum());
				break;
			case '*':
				letter->data.setNum(num1->data.getNum() * num2->data.getNum());
				break;
			case '/':
				if (num2->data.getNum() == 0)	
					throw "[ ���� ]�������� �ι�° �����ڰ� 0�� ��찡 �߻�";
				letter->data.setNum(num1->data.getNum() / num2->data.getNum());
				break;
			case '%':
				if (num2->data.getNum() == 0)	
					throw "[ ���� ] % �� �ι�° �����ڰ� 0�� ��찡 �߻�";
				letter->data.setNum((int)num1->data.getNum() % (int)num2->data.getNum());
				break;
			case '^':
				float num3 = 1;
				int n2 = num2->data.getNum();

				if ((num2->data.getNum() - (int)num2->data.getNum() / 1) != 0)
					throw "[ ���� ] ^�� �ι�° �ǿ����ڰ� ������ �ƴ� ���";

				else if (num2->data.getNum() < 0)	
				{
					for (int i = 0; i > n2; n2++)
						num3 *= num1->data.getNum();
					num3 = 1 / num3;
				}
				else if (num2->data.getNum() > 0)	
				{
					for (int i = 0; i < n2; i++)
						num3 *= num1->data.getNum();
				}
				letter->data.setNum(num3);
				break;
			}
		}
		stack.push(letter);
	}

	else 
	{
		TreeNode<T>* numNode = new TreeNode<T>(input);
		stack.push(numNode);
	}
	root = stack.top();
}

template<class T>
void CalculatorTree<T>::Print(int i, TreeNode<T> *currentNode)
{
	if (currentNode != root)
		cout << " --- ";
	i++;

	if (currentNode->data.getState() == true)
		cout << currentNode->data.getNum();
	else
		cout << (char)currentNode->data.getLetter() << "(" << currentNode->data.getNum() << ")";


	if (currentNode->leftChild != NULL)
		Print(i, currentNode->leftChild);

	if (currentNode->rightChild != NULL)
	{
		cout << endl << "       ";
		for (int k = 1; k < i; k++)
			cout << "          ";

		Print(i, currentNode->rightChild);
	}
}