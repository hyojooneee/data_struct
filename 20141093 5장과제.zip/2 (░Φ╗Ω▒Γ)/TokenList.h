#pragma once
#include "Token.h"
#include<vector>
using namespace std;

class TokenList
{
private:
	vector<Token> tList;
public:
	Token& getToken(int index) { return tList[index]; }
	int getSize() { return tList.size(); }

	void insertToken(Token& token) { tList.push_back(token); }
	void deleteToken() { tList.pop_back(); }
};