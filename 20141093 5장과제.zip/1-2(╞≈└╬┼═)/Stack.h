#pragma once
#include <algorithm>

template <class T>
class Stack
{
private:
	T* stack;
	int top;
	int capacity;

public:
	Stack();
	Stack(int capacity);
	~Stack() {};

	bool IsEmpty() ; 

	T& Top() ; 
	int getTop()  { return top; } 

	void Push(const T& item); 

	void pop();  

	void ChangeSize(T*& a, const int oldSize, const int newSize);
};

template <class T>
Stack<T>::Stack()
{
	capacity = 10;
	stack = new T[capacity];
	top = -1;
}

template <class T>
Stack<T>::Stack(int capacity)
{
	this->capacity = capacity;
	if (capacity < 1)  throw "Stack capacity must be > 0 !";

	stack = new T[capacity];
	top = -1;
}

template <class T>
inline bool Stack<T>::IsEmpty() { return top == -1; }

template <class T>
inline T& Stack<T>::Top()
{
	if (IsEmpty()) throw "Stack is empty!";

	return stack[top];
}

template < class T >
void Stack<T>::Push(const T& x)
{
	if (top == capacity - 1)
	{
		ChangeSize(stack, capacity, 2 * capacity);
		capacity *= 2;
	}
	stack[++top] = x;
}

template <class T>
void Stack<T>::pop()
{
	if (IsEmpty()) throw "Stack is empty. Can not delete!";

	stack[top].~T();
	top--;
}

template <class T>
void Stack<T>::ChangeSize(T*& a, const int oldSize, const int newSize)
{
	if (newSize < 0) throw "New length must be >= 0 !";

	T* temp = new T[newSize];
	int number = min(oldSize, newSize);
	for (int i = 0; i < number; i++)
	{
		temp[i] = a[i];
	}
	delete[] a;
	a = temp;
}