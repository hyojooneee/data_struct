#include "Tree.h"

int main()
{
	Tree<int> tr;
	int nodeNum;

	cout << "��� ������ �Է��ϼ���. : ";
	cin >> nodeNum;

	tr.setTree(nodeNum);
	tr.printPointerTree(tr.getRoot(),0);
	cout << "preorder : ";
	tr.PreOrder();
	cout << "inorder : ";
	tr.InOrder();
	cout << "postorder : ";
	tr.PostOrder();
	cout << "level order : ";
	tr.LevelOrder();

	return 0;
}