#pragma once
#include <string>
#include "Queue.h"
#include "TreeNode.h"
#include "Stack.h"

template <class T>
class Tree
{
private:
	TreeNode<T> * root;
	int nodeNum;

public:
	Tree() { root = NULL; nodeNum = 0; }
	~Tree() {};
	TreeNode<T>* getRoot() const { return root; }

	void setTree(int nodeNum);
	void printPointerTree(TreeNode<T>* cur, int count);
	void InOrder();
	void PreOrder();
	void PostOrder();
	void LevelOrder();
};

template <class T>
void Tree<T>::setTree(int nodeNum)
{
	this->nodeNum++;
	root = new TreeNode<T>(this->nodeNum);
	Queue<TreeNode<T>*> qu;

	TreeNode<T>* cur = root;

	while (1)
	{
		if (cur->leftChild == NULL)
		{
			this->nodeNum++;
			TreeNode<T>* newNode = new TreeNode<T>(this->nodeNum);
			cur->leftChild = newNode;
			qu.push(cur->leftChild);
		}
		else if (cur->rightChild == NULL)
		{
			this->nodeNum++;
			TreeNode<T>* newNode = new TreeNode<T>(this->nodeNum);
			cur->rightChild = newNode;
			qu.push(cur->rightChild);
		}

		else
		{
			cur = qu.getFront();
			qu.pop();
		}
		if (this->nodeNum == nodeNum) break;
	}
}

template <class T>
void Tree<T>::printPointerTree(TreeNode<T>* cur, int count)
{
	if (cur != NULL)
	{
		if (cur->data == 1) cout << cur->data;

		else cout << " ---" << cur->data;


		printPointerTree(cur->leftChild, ++count);
		if (cur->leftChild == NULL)
			cout << endl;


		if (cur->rightChild != NULL)
		{
			cout << " ";
			for (int i = 0; i < count - 1; i++) { cout << "     "; }
		}
		printPointerTree(cur->rightChild, count--);

	}
}


template <class T>
void Tree<T>::InOrder()
{
	TreeNode<T>* cur = root;
	Stack<TreeNode<T>*> st;

	while (1)
	{

		while (cur != NULL)
		{
			st.Push(cur);
			cur = cur->leftChild;
		}
		if (st.IsEmpty()) break;

		cur = st.Top();
		st.pop();
		cout << cur->data << " ";
		cur = cur->rightChild;
	}
	cout << endl;
}

template <class T>
void Tree<T>::PreOrder()
{
	TreeNode<T>* cur = root;
	Stack<TreeNode<T>*> st;

	while (1)
	{
		while (cur != NULL)
		{
			cout << cur->data << " ";

			if (cur->rightChild) st.Push(cur->rightChild);

			cur = cur->leftChild;
		}

		if (st.IsEmpty()) break;

		cur = st.Top();
		st.pop();
	}
	cout << endl;
}

template <class T>
void Tree<T>::PostOrder()
{
	TreeNode<T>* cur = root;
	Stack<TreeNode<T>*> st;

	while (1)
	{
		while (cur != NULL)
		{
			if (cur->rightChild) st.Push(cur->rightChild);

			st.Push(cur);

			cur = cur->leftChild;
		}

		cur = st.Top();
		st.pop();

		if (st.IsEmpty()) { cout << cur->data << " "; break; }

		if (cur->rightChild && cur->rightChild == st.Top())
		{
			st.pop();
			st.Push(cur);
			cur = cur->rightChild;
		}
		else
		{
			cout << cur->data << " ";
			cur = NULL;
		}
	}
	cout << endl;
}

template <class T>
void Tree<T>::LevelOrder()
{
	TreeNode<T>* cur = root;
	Queue<TreeNode<T>*> qu;

	qu.push(cur);

	while (!qu.isEmpty())
	{
		cur = qu.getFront();
		cout << cur->data << " ";
		qu.pop();

		if (cur->leftChild) qu.push(cur->leftChild);

		if (cur->rightChild) qu.push(cur->rightChild);
	}
	cout << endl;
}