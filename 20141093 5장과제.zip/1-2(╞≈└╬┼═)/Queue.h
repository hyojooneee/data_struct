#pragma once

template <class T>
class Queue
{
private:
	T* queue;
	int capacity;
	int front;
	int rear;
	void changeSizeDouble();
	void copyArray(T* begin, T* end, T* dept);

public:
	Queue();
	~Queue() { delete[] queue; }
	bool isEmpty() { return front == rear; }
	bool isFull() { return (rear + 1) % capacity == front; }
	void push(T data);
	void pop();
	T getFront() { return queue[front]; }
	T getRear() { return queue[rear - 1]; }
};

template <class T>
Queue<T>::Queue()
{
	front = 0;
	rear = 0;
	capacity = 10;
	queue = new T[capacity];
}

template <class T>
void Queue<T>::push(T data)
{
	if (isFull()) changeSizeDouble();

	queue[rear] = data;
	rear = (rear + 1) % capacity;
}

template <class T>
void Queue<T>::pop()
{
	if (isEmpty()) throw "Queue is empty!";

	queue[front].~T();
	front = (front + 1) % capacity;
}

template <class T>
void Queue<T>::copyArray(T* begin, T* end, T* dept)
{
	for (; begin != end; begin++)
	{
		*dept = *begin;
		dept++;
	}
	*dept = *end;
}

template <class T>
void Queue<T>::changeSizeDouble()
{
	capacity = capacity * 2;
	T* temp = new T[capacity];

	if (front > rear)
	{
		copyArray(queue + front, queue + capacity - 1, temp);
		copyArray(queue, queue + rear, temp + (capacity / 2 - front));
		rear = rear + capacity / 2;
		rear = rear - front;
		front = 0;
	}
	else
	{
		copyArray(queue + front, queue + rear, temp);
		rear = rear - front;
		front = 0;
	}

	delete[] queue;
	queue = temp;
}

