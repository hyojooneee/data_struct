#pragma once
#include<iostream>
using namespace std;

template <class T> class Tree; // ���� ����

template <class T>
class TreeNode
{
private:
	T data;
	TreeNode<T>* leftChild;
	TreeNode<T>* rightChild;



public:
	friend class Tree<T>;
	T getData() { return data; }
	TreeNode() {leftChild = NULL; rightChild = NULL;}
	TreeNode(T data) { this->data = data; leftChild = NULL; rightChild = NULL; };
	~TreeNode() {};

};
