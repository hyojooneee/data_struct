#pragma once
#include <iostream>
using namespace std;

template <class T>
class ArrTree
{
private:
	T* arr; // �迭

public:
	ArrTree() {};
	ArrTree(T nodeCount);
	~ArrTree(void) {}

	void printArrTree(int curr, int count,int nodeCount);

	int preOrder(int curr, int nodeCount);
	int inOrder(int curr, int nodeCount);
	int postOrder(int curr, int nodeCount);
	void levelOrder(int nodeCount);
};

template <class T>
ArrTree<T>::ArrTree(T nodeCount)
{
	arr = new int[100];
	for (int i = 1; i <= nodeCount; i++) { arr[i] = i; }
}

template <class T>
void ArrTree<T>::printArrTree(int curr, int count,int nodeCount)
{
	if (curr <= nodeCount)
	{
		if (curr == 1)cout << curr;

		if (count != 0)
			cout << " ---" << curr;
				
		printArrTree(curr * 2, ++count, nodeCount);

		if (curr * 2 < nodeCount)
			cout << endl;

		if (count != 0)
			cout << " ";

		count--;
		for (int i = 0; i < count; i++)
			cout << "     ";

		printArrTree(curr * 2 + 1, ++count, nodeCount);
	}
}



template <class T>
int ArrTree<T>::preOrder(int curr, int nodeCount)
{
	if (curr > nodeCount) return 0;
	cout << arr[curr] << " ";
	preOrder(2 * curr, nodeCount);
	preOrder(2 * curr + 1, nodeCount);
}

template <class T>
int ArrTree<T>::inOrder(int curr, int nodeCount)
{
	if (curr > nodeCount) return 0;
	inOrder(2 * curr, nodeCount);
	cout << arr[curr] << " ";
	inOrder(2 * curr + 1, nodeCount);
}

template <class T>
int ArrTree<T>::postOrder(int curr, int nodeCount)
{
	if (curr > nodeCount) return 0;
	postOrder(2 * curr, nodeCount);
	postOrder(2 * curr + 1, nodeCount);
	cout << arr[curr] << " ";
}

template <class T>
void ArrTree<T>::levelOrder(int nodeCount)
{
	for (int i = 1; i <= nodeCount; i++) 
	 cout << arr[i] << " "; 
}