#include "ArrTree.h"

int main()
{
	int nodeCount;
	int root = 1;

	cout << "��� ������ �Է��Ͻÿ� : ";
	cin >> nodeCount;

	ArrTree<int> tr(nodeCount);
	tr.printArrTree(root,0, nodeCount);
	cout << endl;
	cout << "preorder : ";
	tr.preOrder(root, nodeCount);
	cout << endl << "inorder : ";
	tr.inOrder(root, nodeCount);
	cout << endl << "postorder : ";
	tr.postOrder(root, nodeCount);
	cout << endl << "level order : ";
	tr.levelOrder(nodeCount);
	cout << endl;
}