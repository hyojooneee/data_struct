#include"chain.h"
istream& operator>>(istream& is, chain& c)	// ������ ����� ��� ������ �ٷ� �� �ޱ� ������, ��� �Լ��� ���� �Ķ���ͷ� ���� �Ѱ� ó�� �ϴ� ���� �����ϴ�
{
	int coef;	int exp;
	while (1)
	{
		cin >> coef >> exp;

		if (coef == 0 && exp == 0)
			break;

		c.newTerms(coef, exp);

		if (coef == 0 || exp == 0)
			break;
	}

	return is;
}

ostream& operator<<(ostream& os, chain& c)
{
	c.print();
	return os;
}

void chain::print()
{
	Node *pointerNode = headerNode.link;
	Node *previousNode = 0;

	while (1)
	{
		if (pointerNode == 0)
		{
			break;
		}

		if (pointerNode->coef > 0)
		{
			if (previousNode != 0)	// + ���� �ʿ� ����.
				cout << " + ";



			if (pointerNode->exp == 0)
				cout << pointerNode->coef;


			else if (pointerNode->exp == 1)
			{
				if (pointerNode->coef != 1)
					cout << pointerNode->coef;

				cout << "x";
			}


			else
			{
				if (pointerNode->coef != 1)
					cout << pointerNode->coef;

				cout << "x^" << pointerNode->exp;

			}
		}

		else if (pointerNode->coef < 0)
		{
			if (previousNode != 0)
				cout << " ";

			cout << "-";

			if (previousNode != 0)
				cout << " ";


			if (pointerNode->coef != -1 && pointerNode->coef != 1)
				cout << pointerNode->coef * (-1);

			/*else
				cout << pointerNode->coef * (-1);*/


			if (pointerNode->exp == 1)
			{
				cout << "x";
			}



			else if (pointerNode->exp == 0)
			{

			}

			else
			{
				cout << "x^" << pointerNode->exp;
			}


		}
		else
		{
			cout << "0";
		}


		previousNode = pointerNode;
		pointerNode = pointerNode->link;
	}


}
void chain::newTerms(int coef, int exp)
{
	Node *addNode = new Node(coef, exp, 0);

	if (headerNode.link == 0)	// �������� ��尡 �ϳ��� ���� ��.
	{
		headerNode.link = addNode;
	}

	else
	{
		Node *previousNode = &headerNode;
		Node *currentNode = headerNode.link;
		while (1)
		{
			if (exp > currentNode->exp)
			{
				addNode->link = currentNode;
				previousNode->link = addNode;
				break;
			}

			if (currentNode->link == 0)
			{
				currentNode->link = addNode;
				break;
			}

			previousNode = currentNode;
			currentNode = currentNode->link;
		}
	}
}

chain chain::operator*(chain& c)
{
	Node *aPointer = this->headerNode.link;
	Node *bPointer = c.headerNode.link;

	chain multi;

	while (1)
	{

		if (aPointer == 0)
			break;

		chain temp;

		while (1)
		{
			if (bPointer == 0)
				break;

			int tempCoef = aPointer->coef * bPointer->coef;
			int tempExp = aPointer->exp + bPointer->exp;

			temp.newTerms(tempCoef, tempExp);
			bPointer = bPointer->link;
		}
		
		multi = multi + temp;
		bPointer = c.headerNode.link;
		aPointer = aPointer->link;
	}
	return multi;
}

chain chain::operator+(chain &c)
{
	chain result;

	Node *aPointer = this->headerNode.link;
	Node *bPointer = c.headerNode.link;

	while (1)
	{

		if (aPointer == 0 || bPointer == 0)		// ������ �ɶ�.
			break;

		if (aPointer->exp == bPointer->exp)		// ���� ��
		{
			int tempCoef = aPointer->coef + bPointer->coef;
			int tempExp = aPointer->exp;
			if (tempCoef)
				result.newTerms(tempCoef, tempExp);

			aPointer = aPointer->link;
			bPointer = bPointer->link;
		}

		else if (aPointer->exp > bPointer->exp)
		{
			result.newTerms(aPointer->coef, aPointer->exp);
			aPointer = aPointer->link;
		}

		else
		{
			result.newTerms(bPointer->coef, bPointer->exp);
			bPointer = bPointer->link;
		}

	}

	while (1)
	{
		if (aPointer == 0)
			break;

		result.newTerms(aPointer->coef, aPointer->exp);

		aPointer = aPointer->link;
	}

	while (1)
	{
		if (bPointer == 0)
			break;

		result.newTerms(bPointer->coef, bPointer->exp);

		bPointer = bPointer->link;
	}

	//cout << result << endl;
	return result;
}


chain& chain::operator=(const chain& c)
{
	this->~chain();

	Node *toCopy = c.headerNode.link;
	Node *toCopied = &headerNode;

	while (1)
	{
		if (toCopy == 0)
			break;

		Node *addNode = new Node(toCopy->coef, toCopy->exp, 0);

		if (toCopied->link == 0)
		{
			toCopied->link = addNode;	// ���⼭ ���� �߻��޾���
		}
		else
		{
			while (1)
			{
				if (toCopied->link == 0)
					break;

				toCopied = toCopied->link;
			}

			toCopied->link = addNode;
		}

		toCopy = toCopy->link;
		toCopied = &headerNode;
	}
	return *this;
}// ���� ������ �����ε�


