#pragma once
#include<iostream>
#include<string>
using namespace std;

class chain;

class Node {
	friend class chain;
private:
	int coef;	// ���	
	int exp;	// ����
	Node *link;

public:
	Node()
	{
		coef = 0;	exp = 0;	link = 0;
	}
	Node(int coef, int exp, Node *link)
	{
		this->coef = coef;
		this->exp = exp;
		this->link = link;
	}

};

class chain {
	friend ostream& operator<<(ostream& os, chain& c);
	friend istream& operator>>(istream& is, chain& c);
private:
	Node headerNode;
public:
	chain()
	{
		headerNode = Node();
	}

	chain(const chain &c)
	{
		Node *toCopy = c.headerNode.link;
		Node *toCopied = &headerNode;

		while (1)
		{
			if (toCopy == 0)
				break;

			Node *addNode = new Node(toCopy->coef, toCopy->exp, 0);

			if (toCopied->link == 0)
			{
				toCopied->link = addNode;	// ���⼭ ���� �߻��޾���
			}
			else
			{
				while (1)
				{
					if (toCopied->link == 0)
						break;

					toCopied = toCopied->link;
				}

				toCopied->link = addNode;
			}

			toCopy = toCopy->link;
			toCopied = &headerNode;
		}
		
	}

	~chain()
	{
		Node *baseNode = &headerNode;
		Node *tempNode;

		while (1)
		{
			if (baseNode->link == 0)
				break;

			tempNode = baseNode->link;

			baseNode->link = tempNode->link;

			delete tempNode;
		}
	}

	void newTerms(int coef, int exp);


	chain operator*(chain& c);
	chain operator+(chain& c);
	chain& operator=(const chain& c);
	void print();
};